## Tarefas

- [x] Pesquisar especificações e protocolos do drone SJRC F11
- [x] Analisar opções de comunicação e controle
- [x] Desenvolver aplicação de controle
- [x] Criar documentação e instruções de uso
- [x] Entregar sistema completo ao usuário

